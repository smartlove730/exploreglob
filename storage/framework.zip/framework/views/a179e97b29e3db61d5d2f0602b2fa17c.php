

<?php $__env->startSection('content'); ?>
<div class="container my-5">
  <h1 class="mb-4 fw-bold text-center">All Blogs</h1>

  <div class="row g-4">
    <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="col-md-6 col-lg-4">
        <div class="card h-100 shadow-sm">
          
          
          <?php if($blog->featured_image): ?>
            <img src="<?php echo e(asset($blog->featured_image)); ?>" 
                 class="card-img-top" 
                 alt="<?php echo e($blog->title); ?>">
          <?php endif; ?>

          <div class="card-body d-flex flex-column">
            
            <h5 class="card-title">
              <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="text-decoration-none text-dark">
                <?php echo e($blog->title); ?>

              </a>
            </h5>

            
            <p class="card-text text-muted flex-grow-1">
              <?php echo e(Str::limit($blog->excerpt ?? strip_tags($blog->content), 150)); ?>

            </p>

            
            <p class="small text-secondary mb-2">
              <i class="bi bi-calendar"></i> 
              Published: <?php echo e(\Carbon\Carbon::parse($blog->published_at)->format('d M Y')); ?>

            </p>

            
            <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="btn btn-primary mt-auto">
              Read More →
            </a>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="col-12">
        <div class="alert alert-info text-center">
          No blogs found.
        </div>
      </div>
    <?php endif; ?>
  </div>

  
  <div class="d-flex justify-content-center mt-5">
    <?php echo e($blogs->links()); ?>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\D htdocs\mywork\blog-platform\resources\views/blogs/index.blade.php ENDPATH**/ ?>