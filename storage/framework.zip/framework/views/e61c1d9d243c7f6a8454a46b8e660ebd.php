

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-8">
      <h1>Dashboard</h1>
      <p>Welcome to the admin panel.</p>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\exploreglob\app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>