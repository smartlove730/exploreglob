<?php $isEdit = isset($category); ?>
<div class="modal-header">
    <h5 class="modal-title"><?php echo e($isEdit ? 'Edit Category' : 'Create Category'); ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <form id="admin-category-form" method="POST" action="<?php echo e($isEdit ? route('admin.categories.update', $category) : route('admin.categories.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if($isEdit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

        <div class="mb-3">
            <label class="form-label">Name</label>
            <input name="name" class="form-control" value="<?php echo e($isEdit ? $category->name : ''); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Slug</label>
            <input name="slug" class="form-control" value="<?php echo e($isEdit ? $category->slug : ''); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control"><?php echo e($isEdit ? $category->description : ''); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Country</label>
            <select name="country_id" class="form-select">
                <option value="">-- None --</option>
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($co->id); ?>" <?php if($isEdit && $category->country_id == $co->id): ?> selected <?php endif; ?>><?php echo e($co->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="status" value="1" id="catStatus" <?php if($isEdit && $category->status): ?> checked <?php endif; ?>>
            <label class="form-check-label" for="catStatus">Active</label>
        </div>

        <div class="mb-3">
            <button class="btn btn-primary">Save</button>
        </div>
    </form>
</div>
<?php /**PATH D:\D htdocs\mywork\blog-platform\resources\views/admin/categories/partials/form.blade.php ENDPATH**/ ?>