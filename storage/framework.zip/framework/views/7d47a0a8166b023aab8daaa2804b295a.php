

<?php $__env->startSection('title','Blogs'); ?>

<?php $__env->startSection('content'); ?>
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Blogs</h2>
    <button class="btn btn-success" data-modal-url="<?php echo e(route('admin.blogs.createModal')); ?>">New Blog</button>
  </div>

  <table class="table table-striped">
    <thead>
      <tr><th>ID</th><th>Title</th><th>Category</th><th>Status</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($b->id); ?></td>
          <td><?php echo e($b->title); ?></td>
          <td><?php echo e($b->category?->name); ?></td>
          <td><?php echo e($b->status ? 'Published' : 'Draft'); ?></td>
          <td>
            <button class="btn btn-sm btn-primary" data-modal-url="<?php echo e(route('admin.blogs.editModal', $b)); ?>">Edit</button>
            <form action="<?php echo e(route('admin.blogs.destroy', $b)); ?>" method="POST" style="display:inline"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-danger">Delete</button></form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php echo e($blogs->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\exploreglob\app\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>