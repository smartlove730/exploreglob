
<?php $__env->startSection('SeoTags'); ?>
    <?php echo $__env->make('partials.seo', [
    'seo_title' => 'Global Explorer | Explore International Stories & Country Blogs',
    'seo_description' => 'Browse our curated categories of international stories and cultural blogs. From travel to global news, discover the voices that shape our world on Global Explorer.',
    'seo_keywords' => 'global blogs, international stories, travel blogs, cultural articles, worldwide news, global explorer, country-specific blogs',
    'og_image' => asset('images/category-og-image.jpg'), // Consider a specific category-themed image
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
    use Illuminate\Support\Facades\Storage;
 
?>
<!-- Hero Section -->
<section class="hero-section" style="min-height: 35vh;">
    <div class="container">
        <div class="hero-content">
            <h1 class="hero-title">Browse Categories</h1>
            <p class="hero-subtitle">Explore content by category and discover what interests you</p>
        </div>
    </div>
</section>

<div class="container my-5">
    <div class="row g-4">
          

        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php
    $randomImage = Cache::remember('cat_image_' . $category->id, 3600, function() use ($category) {
        $categoryFolder = 'categories/' . $category->name;
        $images = Storage::disk('public')->files($categoryFolder);
        
        return count($images) > 0
            ? asset('storage/' . $images[array_rand($images)])
            : asset('images/default-category.webp');
    });
?>
            <div class="col-md-4 col-sm-6">
                <div class="category-card">
                 <img 
            src="<?php echo e($randomImage); ?>" 
            alt="<?php echo e($category->name); ?>" 
            class="img-fluid mb-3 rounded" loading="lazy"
        >
                    <h5 class="card-title mb-3"><?php echo e($category->name); ?></h5>
                    <p class="card-text mb-4">
                        <?php echo e($category->description ?? 'Explore amazing blogs in this category'); ?>

                    </p>
                    <a href="<?php echo e(route('category.show', $category->slug)); ?>" class="btn btn-primary">
                        Explore Blogs →
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="empty-state">
                    <div class="empty-state-icon">📂</div>
                    <h3>No categories available</h3>
                    <p>Categories will appear here once they are added.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\exploreglob\resources\views/categories/index.blade.php ENDPATH**/ ?>