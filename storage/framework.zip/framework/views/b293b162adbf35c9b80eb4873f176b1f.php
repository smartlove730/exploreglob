

<?php $__env->startSection('title','Categories'); ?>

<?php $__env->startSection('content'); ?>
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Categories</h2>
    <button class="btn btn-success" data-modal-url="<?php echo e(route('admin.categories.createModal')); ?>">New Category</button>
  </div>

  <table class="table table-striped">
    <thead>
      <tr><th>ID</th><th>Name</th><th>Status</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($c->id); ?></td>
          <td><?php echo e($c->name); ?></td>
          <td><?php echo e($c->status ? 'Active' : 'Inactive'); ?></td>
          <td>
            <button class="btn btn-sm btn-primary" data-modal-url="<?php echo e(route('admin.categories.editModal', $c)); ?>">Edit</button>
            <form action="<?php echo e(route('admin.categories.destroy', $c)); ?>" method="POST" style="display:inline"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-danger">Delete</button></form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php echo e($categories->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\exploreglob\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>