<title><?php echo e($seo_title ?? config('app.name')); ?></title>

<meta name="description" content="<?php echo e($seo_description ?? ''); ?>">
<meta name="keywords" content="<?php echo e($seo_keywords ?? ''); ?>">

<meta property="og:title" content="<?php echo e($seo_title ?? ''); ?>">
<meta property="og:description" content="<?php echo e($seo_description ?? ''); ?>">
<meta property="og:type" content="article">
<meta property="og:url" content="<?php echo e(url()->current()); ?>">
<meta property="og:image" content="<?php echo e($og_image ?? asset('default-og.jpg')); ?>">
<?php /**PATH D:\D htdocs\mywork\blog-platform\resources\views/partials/seo.blade.php ENDPATH**/ ?>