

<?php $__env->startSection('title','Create Blog'); ?>

<?php $__env->startSection('content'); ?>
  <h2>Create Blog</h2>
  <form method="POST" action="<?php echo e(route('admin.blogs.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label class="form-label">Title</label>
      <input name="title" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Content</label>
      <textarea name="content" class="form-control" rows="6"></textarea>
    </div>
    <div class="mb-3">
      <button class="btn btn-primary">Save</button>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\D htdocs\mywork\blog-platform\resources\views/admin/blogs/create.blade.php ENDPATH**/ ?>