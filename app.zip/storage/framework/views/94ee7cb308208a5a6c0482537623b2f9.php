

<?php $__env->startSection('title','Edit Blog'); ?>

<?php $__env->startSection('content'); ?>
  <h2>Edit Blog</h2>
  <form method="POST" action="<?php echo e(route('admin.blogs.update', $blog)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-3">
      <label class="form-label">Title</label>
      <input name="title" class="form-control" value="<?php echo e($blog->title); ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Content</label>
      <textarea name="content" class="form-control" rows="6"><?php echo e($blog->content); ?></textarea>
    </div>
    <div class="mb-3">
      <button class="btn btn-primary">Update</button>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\D htdocs\mywork\blog-platform\resources\views/admin/blogs/edit.blade.php ENDPATH**/ ?>