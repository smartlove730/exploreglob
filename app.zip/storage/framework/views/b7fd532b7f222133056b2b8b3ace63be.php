<?php
    $isEdit = isset($blog);
?>
<div class="modal-header">
    <h5 class="modal-title"><?php echo e($isEdit ? 'Edit Blog' : 'Create Blog'); ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <form id="admin-blog-form" method="POST" action="<?php echo e($isEdit ? route('admin.blogs.update', $blog) : route('admin.blogs.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if($isEdit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

        <div class="mb-3">
            <label class="form-label">Title</label>
            <input name="title" class="form-control" value="<?php echo e($isEdit ? $blog->title : ''); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Slug</label>
            <input name="slug" class="form-control" value="<?php echo e($isEdit ? $blog->slug : ''); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Excerpt</label>
            <textarea name="excerpt" class="form-control"><?php echo e($isEdit ? $blog->excerpt : ''); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Content</label>
            <textarea name="content" class="form-control" rows="6"><?php echo e($isEdit ? $blog->content : ''); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Category</label>
            <select name="category_id" class="form-select">
                <option value="">-- None --</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>" <?php if($isEdit && $blog->category_id == $c->id): ?> selected <?php endif; ?>><?php echo e($c->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Country</label>
            <select name="country_id" class="form-select">
                <option value="">-- None --</option>
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($co->id); ?>" <?php if($isEdit && $blog->country_id == $co->id): ?> selected <?php endif; ?>><?php echo e($co->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Featured Image (URL)</label>
            <div class="input-group mb-2">
                <input name="featured_image" class="form-control" value="<?php echo e($isEdit ? $blog->featured_image : ''); ?>">
                <input type="file" class="form-control" id="featured_file" data-upload-url="<?php echo e(route('admin.uploads')); ?>">
            </div>
            <small class="text-muted">You can paste an external URL or upload an image using the file input.</small>
        </div>

        <div class="mb-3">
            <label class="form-label">SEO Title</label>
            <input name="seo_title" class="form-control" value="<?php echo e($isEdit ? $blog->seo_title : ''); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">SEO Description</label>
            <textarea name="seo_description" class="form-control"><?php echo e($isEdit ? $blog->seo_description : ''); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Published At</label>
            <input type="datetime-local" name="published_at" class="form-control" value="<?php echo e($isEdit && $blog->published_at ? $blog->published_at->format('Y-m-d\TH:i') : ''); ?>">
        </div>

        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="status" value="1" id="statusCheck" <?php if($isEdit && $blog->status): ?> checked <?php endif; ?>>
            <label class="form-check-label" for="statusCheck">Published</label>
        </div>

        <div class="mb-3">
            <button class="btn btn-primary">Save</button>
        </div>
    </form>
</div>
<?php /**PATH D:\D htdocs\mywork\blog-platform\resources\views/admin/blogs/partials/form.blade.php ENDPATH**/ ?>