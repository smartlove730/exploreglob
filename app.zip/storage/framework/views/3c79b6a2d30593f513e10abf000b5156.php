

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>All Categories</h1>

    <div class="category-grid">
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="category-card">
                <h2>
                    <a href="<?php echo e(route('category.show', $category->slug)); ?>">
                        <?php echo e($category->name); ?>

                    </a>
                </h2>

                <p><?php echo e($category->description); ?></p>

                <a href="<?php echo e(route('category.show', $category->slug)); ?>" class="btn">
                    View Blogs →
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No categories found.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\D htdocs\mywork\blog-platform\resources\views/categories/index.blade.php ENDPATH**/ ?>