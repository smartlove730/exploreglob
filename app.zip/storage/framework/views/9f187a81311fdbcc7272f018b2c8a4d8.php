

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <!-- Category Header -->
    <div class="mb-4">
        <h1 class="fw-bold"><?php echo e($category->name); ?></h1>
        <?php if($category->description): ?>
            <p class="text-muted lead"><?php echo e($category->description); ?></p>
        <?php endif; ?>
    </div>

    <!-- Blogs Grid -->
    <?php if($blogs->count() > 0): ?>
        <div class="row g-4">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 shadow-sm">
                        <?php if($blog->featured_image): ?>
                            <img src="<?php echo e($blog->featured_image); ?>" 
                                 class="card-img-top" 
                                 alt="<?php echo e($blog->title); ?>"
                                 style="height: 200px; object-fit: cover;">
                        <?php endif; ?>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">
                                <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="text-decoration-none text-dark">
                                    <?php echo e($blog->title); ?>

                                </a>
                            </h5>
                            <p class="card-text text-muted flex-grow-1">
                                <?php echo e(Str::limit($blog->excerpt ?? '', 150)); ?>

                            </p>
                            <div class="d-flex justify-content-between align-items-center mt-auto">
                                <small class="text-muted">
                                    <?php echo e(\Carbon\Carbon::parse($blog->published_at)->format('M d, Y')); ?>

                                </small>
                                <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="btn btn-sm btn-primary">
                                    Read More →
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Pagination -->
        <div class="d-flex justify-content-center mt-5">
            <?php echo e($blogs->links()); ?>

        </div>
    <?php else: ?>
        <div class="alert alert-info text-center">
            <h4>No blogs found in this category yet</h4>
            <p class="mb-0">Check back soon for new content!</p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\D htdocs\mywork\blog-platform\resources\views/categories/show.blade.php ENDPATH**/ ?>