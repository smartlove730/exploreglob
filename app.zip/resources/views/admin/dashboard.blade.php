@extends('admin.layout')

@section('title','Dashboard')

@section('content')
  <div class="row">
    <div class="col-md-8">
      <h1>Dashboard</h1>
      <p>Welcome to the admin panel.</p>
    </div>
  </div>
@endsection
